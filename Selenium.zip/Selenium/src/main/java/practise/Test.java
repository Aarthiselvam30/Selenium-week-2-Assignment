package practise;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		EdgeDriver driver = new EdgeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://system.netsuite.com/pages/customerlogin.jsp");
	
		driver.findElement(By.id("email")).sendKeys("aarthi.selvam@logicinfo.com");
		driver.findElement(By.name("password")).sendKeys("Annapoorani@2020");
		driver.findElement(By.id("submitButton")).click();
		
		String title = driver.getTitle();
		System.out.println(title);
		
		if(title.contains("log")) {
			System.out.println("Login successful");
		}else {
			System.out.println("Login not successful");
		}	
		
		driver.findElement(By.xpath("//label[text()='Submit']")).click();
		
		
	}

}
