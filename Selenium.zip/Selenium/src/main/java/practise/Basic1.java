package practise;

import org.openqa.selenium.chrome.ChromeDriver;

public class Basic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Step - 1: Launch the browser
		
		ChromeDriver driver = new ChromeDriver();
		
		//Step - 2: Maximize the Screen
		
		driver.manage().window().maximize();
		
		//Step - 3: get the Url
		
		driver.get("http://www.leaftaps.com/opentaps/control/main");
		
		//Step - 4: Close the Browser
		
		driver.close();	
		
	}

}
