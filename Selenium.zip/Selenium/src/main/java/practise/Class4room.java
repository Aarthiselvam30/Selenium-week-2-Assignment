package practise;


import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;


public class Class4room {
	
	
	

	public static void main(String[] args) {
		
		EdgeDriver driver = new EdgeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			
	driver.manage().window().maximize();
	
	driver.get("www.amazon.in/");
	
	driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Phones",Keys.ENTER);
	
	List<WebElement> phPrice = driver.findElements(By.className("a-price-whole"));

	//create empty list
	List<Integer> allPrice=new ArrayList<Integer>();
	

	
	for (WebElement j : phPrice) {
		String text = j.getText();
		//System.out.println(text);
		
		//51,790->removing ','->51790
		String replaceAll = text.replaceAll(",", "");
		//System.out.println(replaceAll);
		
		//convert string value into int
		int parseInt = Integer.parseInt(replaceAll);
		//System.out.println(parseInt);
		
		//adding value into empty list
		allPrice.add(parseInt);
		
	}
	Collections.sort(allPrice);
	
	System.out.println(allPrice);
	System.out.println("min value :"+ allPrice.get(0));
}
}
