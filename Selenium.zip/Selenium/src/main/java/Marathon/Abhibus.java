package Marathon;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Abhibus {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.abhibus.com/");
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='From Station']")).sendKeys("Chennai");
		
		driver.findElement(By.xpath("//div[text()='Chennai']")).click();
		
		driver.findElement(By.xpath("//input[@placeholder='To Station']")).sendKeys("Banglore");
		
	
		driver.findElement(By.xpath("//div[text()='Bangalore']")).click();
		
		driver.findElement(By.xpath("//button[text()='Tomorrow']")).click();
		
		String firstname = driver.findElement(By.xpath("//h5[@class='title']")).getText();
		
		System.out.println(firstname);
		
	driver.findElement(By.xpath("(//p[text()='Bus Type']/following::a)[4]")).click();
	
	String seat = driver.findElement(By.xpath("//button[text()='Show Seats']/following::small")).getText();
		
		System.out.println(seat);
		
		driver.findElement(By.xpath("//button[text()='Show Seats']")).click();
		
		driver.findElement(By.xpath("//button[@class='seat sleeper']")).click();
		
		driver.findElement(By.xpath("(//input[@placeholder='Search Boarding Point']/following::input)[1]")).click();
		
		String Seatnumber = driver.findElement(By.xpath("//span[text()='Seat Selected :']")).getText();
		System.out.println(Seatnumber);
		
		String Fare = driver.findElement(By.xpath("(//div[contains(@id,'seating-selected-seat-details')]/span)[2]")).getText();
		
		System.out.println(Fare);
		
		String title = driver.getTitle();
		
		System.out.println(title);
		
		//Thread.sleep(3000);
		
		//driver.close();
		
	
		
		
		
	
	}

	
}
