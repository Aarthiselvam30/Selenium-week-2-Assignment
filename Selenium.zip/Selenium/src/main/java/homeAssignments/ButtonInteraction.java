package homeAssignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ButtonInteraction {

	public static void main(String[] args) throws InterruptedException {

    ChromeDriver driver = new ChromeDriver();
    
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    
    driver.manage().window().maximize();
    
    driver.get("https://leafground.com/button.xhtml");
    
    Thread.sleep(3000);
    
    driver.findElement(By.xpath("(//span[@class='ui-button-text ui-c'])[1]")).click();
    
    String title = driver.getTitle();
    
   System.out.println(title);
   
   Thread.sleep(3000);
   
   if(title.contains("Dash")) {
	   
	  System.out.println("Click successful");
   }else {
	   System.out.println("Click Notsuccessful");
		
   }	
   
   Thread.sleep(3000);
   
   driver.navigate().back();
   
   Thread.sleep(3000);
   
   WebElement element = driver.findElement(By.xpath("//span[text()='Disabled']"));
   
   boolean enabled = element.isEnabled();
   
   if(enabled==false) {
	   System.out.println("Button is disabled");
   }else {
	   
	   System.out.println("Button is enabled");
   }
   
   
   String currentUrl = driver.getCurrentUrl();
   
   System.out.println(currentUrl);
   
   
   
   
   
	//doubt...	how to go back to the previous page.

	}

}
