package homeAssignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Interactionwithcheckbox {

	public static void main(String[] args) throws InterruptedException {
		
  EdgeOptions ed = new EdgeOptions();
  
  ed.addArguments("--guest");
  
  EdgeDriver driver = new EdgeDriver(ed);
  
  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
  
  driver.manage().window().maximize();
  
  driver.get("https://leafground.com/checkbox.xhtml");
  
  driver.findElement(By.xpath("//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default'][1]")).click();
   
  driver.findElement(By.xpath("(//div[@class='col-12'])[2]//div[2]")).click();
    
  String title = driver.getTitle();
  
  System.out.println(title);
  
  driver.findElement(By.className("ui-toggleswitch-slider")).click();
 
  Thread.sleep(3000);
 
  WebElement checked = driver.findElement(By.className("ui-growl-title"));
  
  System.out.println(checked.getText());
  
  driver.findElement(By.className("ui-toggleswitch-slider")).click();
  Thread.sleep(3000);
  WebElement unchecked = driver.findElement(By.className("ui-growl-title"));
  
  String text = unchecked.getText();
  
  if(text.contains("Un")){
	  
	  System.out.println("verified");
	  
  }
  
  System.out.println(unchecked.getText());
  
  
  boolean selected = driver.findElement(By.xpath("//span[text()='Disabled']")).isSelected();
  
  System.out.println(selected);
  
  if(selected==false) {
	  
	  System.out.println("The button is disabled");
	  
	  
  }else {
	  
	  System.out.println("button is enabled");
  }
  
  
  //driver.close();
  
  //Verify if the Checkbox is disabled.
  
  //how to verify the popups.
  
  
  
  
  
	}

}
