package homeAssignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class Facebook {

	public static void main(String[] args) {

        ChromeOptions cd = new ChromeOptions();
        
        cd.addArguments("--guest");
        
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.manage().window().maximize();
		
		driver.get("https://en-gb.facebook.com/");
		
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		
		driver.findElement(By.name("firstname")).sendKeys("Priya");
		
		driver.findElement(By.name("lastname")).sendKeys("Selvam");
		
		driver.findElement(By.name("reg_email__")).sendKeys("varsha.160180@gmail.com");
		
		driver.findElement(By.name("reg_email_confirmation__")).sendKeys("varsha.160180@gmail.com");
		
		driver.findElement(By.name("reg_passwd__")).sendKeys("aarthi@123");
		
		WebElement date = driver.findElement(By.id("day"));
		
		Select day = new Select(date);
		
		day.selectByVisibleText("29");
		
		WebElement months = driver.findElement(By.id("month"));
		
		Select mon = new Select(months);
		
		mon.selectByVisibleText("May");
		
		WebElement years = driver.findElement(By.id("year"));
		
		Select yea = new Select(years);
		
		yea.selectByVisibleText("1998");
		
		driver.findElement(By.xpath("//label[text()='Female']")).click();
		
		driver.findElement(By.name("websubmit")).click();
		
		String title = driver.getTitle();
		
		System.out.println(title);
		
		if(title.contains("Facebook")) {
			System.out.println("Successfull");
		}
		
		else {
			System.out.println("Not successful");
		}
		
		

		
		driver.close();
		
		
		
		

	}

}
