package homeAssignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;




public class RadioButton {

	public static void main(String[] args) throws InterruptedException {
		
		EdgeOptions ed = new EdgeOptions();
		
		ed.addArguments("--guest");
		
		EdgeDriver driver = new EdgeDriver(ed);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.manage().window().maximize();
		
		driver.get("https://www.leafground.com/radio.xhtml");
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//span[@class='ui-radiobutton-icon ui-icon ui-c ui-icon-bullet']")).click();
		
		//Unable to select the xpath
		
		
		
		
		
		
		
		
		

	}

}
