package homeAssignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateAccount {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.manage().window().maximize();
		
		driver.get("http://leaftaps.com/opentaps/");
		
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
		driver.findElement(By.className("decorativeSubmit")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
		
		driver.findElement(By.xpath("//a[text()='Accounts']")).click();
		
		driver.findElement(By.xpath("//a[text()='Create Account']")).click();
		
		driver.findElement(By.id("accountName")).sendKeys("Testing");
		
		driver.findElement(By.name("description")).sendKeys("Selenium Automation Tester");
		
		WebElement dropdown = driver.findElement(By.name("industryEnumId"));
		
		Select option = new Select(dropdown);
		
		option.selectByVisibleText("Computer Software");
		
		WebElement industry = driver.findElement(By.name("ownershipEnumId"));
		
		Select button = new Select(industry);
		
		button.selectByVisibleText("S-Corporation");
		
		WebElement source = driver.findElement(By.id("dataSourceId"));
		
	    Select options = new Select (source);
	    
	    options.selectByVisibleText("Employee");
	    
	    WebElement element = driver.findElement(By.id("marketingCampaignId"));
	    
	    Select marketcompaign = new Select (element);
	    
	    marketcompaign.selectByIndex(6);
	    
	    WebElement findElement = driver.findElement(By.id("generalStateProvinceGeoId"));
	    
	    Select state = new Select(findElement);
	    
	    state.selectByValue("TX");
	    
	    driver.findElement(By.className("smallSubmit")).click();
	    
	    
	    String title = driver.getTitle();
	    
	    System.out.println(title);
	    
	    if(title.contains("Create")) {
	    	
	    	System.out.println("the title is correct");
	    	
	    }else {
	    	
	    	
	    	System.out.println("The title is wrong");
	    }
	    
	    
	    Thread.sleep(6000);
	    
	    
	driver.close();
	    
	    
		
		
		
		
		
		
		
		
		
	}

}
