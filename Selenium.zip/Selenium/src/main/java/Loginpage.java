import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Loginpage {
	public static void main(String[] args) throws InterruptedException {
		
		
		//Step- 1: open the browser
		ChromeDriver driver=new ChromeDriver();
		
		//Step- 2: Maximize the window
		driver.manage().window().maximize();
		
		//Step- 3: Launch the URL
		driver.get("http://www.leaftaps.com/opentaps/control/main");
		
		//Step- 4: Enter the usernmae and password
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();
		
		
		String title = driver.getTitle();
		System.out.println(title);
		
		driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
		driver.findElement(By.xpath("//a[text()='Accounts']")).click();
		driver.findElement(By.xpath("//a[text()='Create Account']")).click();
		driver.findElement(By.xpath("//input[@id='accountName']")).sendKeys("Bank Account");
		WebElement industry = driver.findElement(By.name("industryEnumId"));
		Select dropdown1 = new Select(industry);
		dropdown1.selectByVisibleText("Computer Software");
		
		
		
		
		
		
		
		
		
		//Step- 4: CLose the browser
		//driver.close();
		
		
		
		
		
//		ChromeDriver driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("http://www.leaftaps.com/opentaps/control/main");
//		
//		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
//		driver.findElement(By.id("password")).sendKeys("crmsfa");
//		driver.findElement(By.className("decorativeSubmit")).click();
//		
//		//ctrl+2-l
//		String title = driver.getTitle();
//		System.out.println(title);
//		
//		//contains will partial match
//		if(title.contains("TestLeaf Automation")) {
//			System.out.println("login is successful");
//		}else {
//			System.out.println("login is not successful");
//		}
//		
//	//	driver.findElement(By.linkText("CRM/SFA")).click();
//		
//		driver.findElement(By.partialLinkText("CRM/")).click();
//		
//		//java wait
//		
	Thread.sleep(5000);
		
		driver.close();
		
		
		
			
	}
	
	

}
